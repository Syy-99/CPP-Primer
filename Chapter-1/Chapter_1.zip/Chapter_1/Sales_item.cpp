//
// Created by 沈衍羽 on 2022/1/14.
//
#include <iostream>
#include "Sales_item.h"
#include <string>
const std::string &Sales_item::getIsbn() const {
    return ISBN_;
}

void Sales_item::setIsbn(const std::string &isbn) {
    ISBN_ = isbn;
}

int Sales_item::getNum() const {
    return num_;
}

void Sales_item::setNum(int num) {
    num_ = num;
}

double Sales_item::getPrice() const {
    return price_;
}

void Sales_item::setPrice(double price) {
    price_ = price;
}

std::ostream &operator<<(std::ostream &os, const Sales_item &item) {
    os << "ISBN_: " << item.ISBN_ << " num_: " << item.num_ <<" sum_profit_ "<< item.sum_profit_<<" price_: " << item.price_;
    return os;
}

std::istream &operator>>(std::istream &is, Sales_item &item) {
  //  return <#initializer#>;
    is>>item.ISBN_>>item.num_>>item.price_;
    item.sum_profit();
    return is;
}

Sales_item operator+(const Sales_item item1, const Sales_item item2) {
    Sales_item item_New;
    if (item1.ISBN_ == item2.ISBN_) {
        item_New.ISBN_ = item1.ISBN_;
        item_New.num_ = item1.num_ + item2.num_;
        item_New.sum_profit_ = item1.sum_profit_ + item2.sum_profit_;
        item_New.price_ = item_New.sum_profit_/item_New.num_;
    } else
        std::cout<<"不是同一本书"<<std::endl;
    return item_New;
}
