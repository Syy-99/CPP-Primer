//
// Created by 沈衍羽 on 2022/1/14.
//

#ifndef CHAPTER_1_SALES_ITEM_H
#define CHAPTER_1_SALES_ITEM_H

class Sales_item {
    friend std::ostream &operator<<(std::ostream &os, const Sales_item &item);
    friend std::istream &operator>>(std::istream &is, Sales_item &item);
    friend Sales_item operator+(const Sales_item item1, const Sales_item item2);
public:
    const std::string &getIsbn() const;

    void setIsbn(const std::string &isbn);

    int getNum() const;

    void setNum(int num);

    double getPrice() const;

    void setPrice(double price);



private:
    std::string ISBN_;
    int num_;
    double price_;

    double sum_profit_;

    void sum_profit() {
        sum_profit_ = num_*price_;
    }

};
#endif //CHAPTER_1_SALES_ITEM_H
