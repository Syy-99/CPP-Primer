#include <iostream>
#include <algorithm>
#include "Sales_item.h"
void fun1_2() {
    std::cout<<"Enter two nums:"<<std::endl;
    int v1 = 0, v2 = 0;
    std::cin>>v1>>v2;
    std::cout<<"The sum of";
    std::cout<<v2<<" and ";
    std::cout<<v2<<" is ";
    std::cout<<v1+v2<<std::endl;
}
void fun1_4() {
    int count = 50;
    int sum = 0;
    while (count<=100) {
        //  std::cout<<count<<" ";
        sum += count++;
    }
    std::cout<<sum<<std::endl;
//----------------------------------------------------
    int count_2 = 10;
    while (count_2>=0) {
        std::cout<<count_2--<<" ";
    }
//-------------------------------------------------------
    int num1, num2;
    std::cout<<"Enter two nums:";
    std::cin>>num1>>num2;
    for ( int i = std::min(num1, num2); i <= std::max(num1,num2); ++i) {
        std::cout<<i<<" ";
    }
    //-----------------------------------------------------
    //    int sum = 0;
//    for (int i = -100; i <= 100; ++i)
//        sum += i;
//    std::cout << sum;

//    int num;		// 假设是整数
//    int sum = 0;
//    while (std::cin>>num) {
//        sum += num;
//    }
//    std::cout<<sum<<std::endl;
}
void Ex1_18 () {
    int curr_val = 0, val = 0;
    if (std::cin >> curr_val) {
        int cnt = 1;
        while (std::cin >> val) {
            if (val == curr_val)
                ++cnt;
            else {
                std::cout<<curr_val<<" occurs "<<cnt<<" times "<<std::endl;
                cnt = 1;
                curr_val = val;
            }
        }
        std::cout<<curr_val<<" occurs "<<cnt<<" times "<<std::endl;
    }
}

void Chap1_5() {
//    Sales_item books;
//    std::cin>>books;
//    std::cout<<books<<std::endl;
//------------------------------------------------

    Sales_item item1, item2;
    std::cin>>item1>>item2;
    std::cout<<item1 + item2<<std::endl;
//-------------------------------------------------
}
void Ex1_5_2() {
    Sales_item item;
    std::string temp;
    if(std::cin>>item) {
        temp = item.getIsbn();
        int count = 1;
        while (std::cin >> item) {
            if (temp == item.getIsbn()) {
                ++count;
            } else {
                std::cout << temp << " occur " << count << " times " << std::endl;
                count = 1;
                temp = item.getIsbn();
            }
        }
        std::cout << temp << " occur " << count << " times " << std::endl;
    }
}
int main() {
   // Chap1_5();
  //  Ex1_5_2();
   // Ex1_18();
    return 0;
}
