#include <iostream>
void Ex2_3() {
    unsigned u = 10, u2 = 42;
    std::cout<<u2 - u<<std::endl;
    std::cout<<u - u2<<std::endl;

    int i = 10;
    std::cout<<i - u<<std::endl;
}
void Ex2_14() {
    int i = 100, sum = 0;
    for (int i = 0; i != 10; ++i)
        sum += i;
    std::cout << i << " " << sum << std::endl;
}
    void f(int a){

};

int main() {
//    Ex2_3();
 //   Ex2_14();

    return 0;
}
