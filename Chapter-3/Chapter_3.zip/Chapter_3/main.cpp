#include <iostream>
#include <vector>
#include <cstring>
using namespace std;
void Ex3_2 () {
    // 一次读取一行
//    string s;
//    while (getline(cin,s)) {
//        cout<<s<<endl;
//    }
// 一次读取一个词
    string s;
    while (cin>>s) {
        cout<<s<<endl;
    }
}

void Ex3_4() {
    string s1, s2;
    cin>>s1>>s2;
    if (s1 == s2) {
        cout<<"same"<<endl;
    } else {
        cout<<(s1 > s2 ? s1:s2)<<endl;
    }
    // 判断是否等长
    if ( s1.size() == s2.size() ) {
        cout<<"equal"<<endl;
    } else {
        cout<<(s1.size() > s2.size() ? s1 : s2)<<endl;
    }

}

void Ex3_5() {
    string s;
    string sum;
    while(cin >> s) {
      //  sum += s;
        sum = sum+ s+" ";
    }
    cout<<sum<<endl;
}

void Ex3_6() {
    string s = "123";
    for (auto &c : s) {
        c = 'X';
    }
    cout<<s<<std::endl;
}

void Ex3_10() {
    string s;
    cin>>s;
    string s_deal;
    for (auto c : s) {
        if (!std::ispunct(c))
            s_deal += c;
    }
    cout<<s_deal<<endl;
}

void Ex3_18() {
    vector<string> svec;
    string temp;
    while (cin>>temp) {
        svec.push_back(temp);
    }
    for (auto &s : svec) {
        for (auto &c : s) {
            c = toupper(c);
        }
    }
    for (auto s : svec)
        cout<<s<<" ";
    cout<<endl;
}

void Ex3_20() {
    vector<int> ivec;
    int temp = 0;
    while (cin >> temp) {
        ivec.push_back(temp);
    }
    int sum_adjacent = 0;
//    for (int i = 0; i < ivec.size(); ++i) {
//        sum_adjacent += ivec[i];
//        if ( i % 2 == 1) {
//            cout<<sum_adjacent<<" ";
//            sum_adjacent = 0;
//        }
//    }
    int l = ivec.size() - 1;
    for ( int i = 0; i <= l/2; ++i) {
        if ( i == l - i) {          // 处理奇数个中间的
            cout<<ivec[i]<<" ";
            break;
        }
        cout<<(ivec[i] + ivec[l - i])<<" ";
    }
}

void EX3_23() {
    vector<int> ivec(10,1);
    for (auto it = ivec.begin(); it != ivec.end(); ++it) {
        *it *= 2;
    }
    cout<< *(ivec.begin())<<endl;
}

using int_array = int[3];
int main() {
    //Ex3_4();
   // Ex3_5();
//   Ex3_6();
   // Ex3_10();
   // Ex3_18();
    int ia[3][3]={1,2,4,5,5};


    for (int (*p)[3] = begin(ia); p != end(ia); ++p)
        for(int *q = *p; q!= end(*p); ++q)
    cout<<*q<<" ";
}
