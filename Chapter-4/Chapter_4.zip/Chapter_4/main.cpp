#include <iostream>
#include <vector>
using namespace std;
void Ex4_15() {
    double dval;
    int ival;
    int *pi;

   // dval = ival = pi =0; 编译不通过
}

void Ex4_20() {
    vector<string> ivec = {"a","b","c"};
    auto iter = ivec.begin();
    cout<<*iter++<<endl;
    cout<<*iter;
 //   cout<<*iter.empty();
    cout<<iter->empty();
    cout<<iter++->empty();
    cout<<*iter;
}

void Ex4_21() {
    vector<int> ivec = {1,2,3,4,5,6};
    for (auto &i : ivec)
        i = i % 2? 2*i : i;
    cout<<ivec[0];
}
int main() {
 //   Ex4_20();
   // Ex4_21();
    auto i = 1.32;
    cout<<i;

    return 0;
}
