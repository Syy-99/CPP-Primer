#include <iostream>
#include <map>
#include <vector>
#include <exception>
using namespace std;
void Ex5_9_11() {
    char c;
    map<string,int> map_s_i;
    while(cin.get(c)) {
        if (c == 'a' || c == 'A')
            ++map_s_i["a"];
        else if (c == 'e' || c == 'E')
            ++map_s_i["e"];
        else if (c == 'i' || c == 'I')
            ++map_s_i["i"];
        else if (c == 'o' || c == 'O')
            ++map_s_i["o"];
        else if (c == 'u' || c == 'U')
            ++map_s_i["u"];
        else if (c == ' ')
            ++map_s_i["space"];
        else if (c == '\t' || c == '\n')
            ++map_s_i["t+n"];

    }

    for (auto p : map_s_i)
        cout<<p.first<<" "<<p.second<<endl;
}

void Ex5_14() {
    string s_cur;
    string s_before;
    map<string,int> map_s_i;
    int count = 1;
    while(cin>>s_cur) {
        if(s_cur != s_before) {
            if (count > map_s_i[s_cur])
                map_s_i[s_before] = count;
            count = 1;
        }
        else {
            ++count;
        }
        s_before = s_cur;       // 记录
    }
    int max = -1;
    for(auto p : map_s_i)
    {
       max = p.second >= max? p.second:max;
    }
    for(auto p : map_s_i) {
        if ( p.second == max)
            cout<<p.first<<endl;
    }
}

void Ex5_17() {
    vector<int> vec_i_1 = {0,1,1,2};
    vector<int> vec_i_2 = {0,1,1,2,3,5,8};
    for (int i = 0 ; i < vec_i_1.size() && i < vec_i_2.size(); ++i ) {
        if(vec_i_1[i] != vec_i_2[i])   {
            cout<<"false";
            return;
        }
    }
    cout<<"true";
}
int main() {
    //Ex5_9_11();
  //  Ex5_14();
   // Ex5_17();
    try {
        cout<<2.0/0;
    }catch (runtime_error e){
      //  cout<<"t";
        cout<<e.what();
    }

    return 0;
}
