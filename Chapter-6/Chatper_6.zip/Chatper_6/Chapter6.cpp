//
// Created by 沈衍羽 on 2022/1/23.
//

#include <string>
long long Ex6_3 (int n ) {
    long long sum = 1;
    while(n > 1)
        sum *= n--;
    return sum;
}

int Ex6_7() {
    static int count = 0;
    return count++;
}

void Ex6_10(int *p1, int *p2) {
    int temp = *p1;
    *p1 = *p2;
    *p2 = *p1;
}

bool Ex6_17(const std::string &s) {
    for (auto sval : s)
        if (!std::isupper(sval))
            return false;
    return true;
}

void Ex6_17_2(std::string &s) {
    for (auto &sval : s)
        if (!std::isupper(sval))
            sval = toupper(sval);
}