//
// Created by 沈衍羽 on 2022/1/23.
//

#ifndef CHATPER_6_CHAPTER6_H
#define CHATPER_6_CHAPTER6_H
long long Ex6_3 (int n );
int Ex6_7();
void Ex6_10(int *p1, int *p2);
bool Ex6_17(const std::string &s);
void Ex6_17_2(std::string &s);
#endif //CHATPER_6_CHAPTER6_H
