#include <iostream>
#include <vector>
#include <initializer_list>
#include "Chapter6.h"
using namespace std;
void Ex6_27(initializer_list<int> ival_list) {
    int sum = 0;
    for (auto ival : ival_list)
        sum += ival;
    cout<<sum<<endl;
}

void Ex6_33(vector<int> ivec, int i = 0) {
    if (i == ivec.size())
        return;
    cout<<ivec[i++]<<" ";
    Ex6_33(ivec,i);
}

//6.7节练习
int fun1(int ival1, int ival2){
    return ival1 + ival2;
}
int fun2(int ival1, int ival2){
    return ival1 - ival2;
}
int fun3(int ival1, int ival2){
    return ival1 * ival2;
}
int fun4(int ival1, int ival2){
    return ival1 / ival2;
}
void Ex6_54_56(){

    using fun1_ptr = int (*)(int,int);

    vector<fun1_ptr> vec_fun1 = {fun1,fun2,fun3, fun4};
    int ival1= 44, ival2 = 4;
    for (auto fun : vec_fun1)
        cout<<fun(ival1,ival2)<<endl;
}

int main() {
  //  Ex6_27({1,2,3,4});
    Ex6_54_56();

    return 0;
}
